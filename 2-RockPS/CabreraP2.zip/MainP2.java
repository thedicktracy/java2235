//////////////////////////////////////////////////////////////////////////////////////////////
// Programmer: Robert Cabrera
// Email: rcabrera14@cnm.edu
// Program Name: Rock Paper Scissors
// File Name: MainP2.java
//////////////////////////////////////////////////////////////////////////////////////////////

import java.util.Random;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MainP2 {

    public static void main(String[] args){
        RockUI ui=new RockUI();
        ui.play();
        System.exit(0);
        
        

                                            }

}